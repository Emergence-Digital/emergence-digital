# Output Template

Use this structure. Replace everything in [brackets].

---

# Case Study: [headline result]

*Built with the Centurion Strategy Case Study Generator · [date]*

**To confirm before publishing:** [placeholders, e.g. the downtime figure, a client quote. Or "Nothing, ready to go."]
**Removed for safety:** [anything the safety check took out, or "Nothing."]

## 1. Unbranded client story (publish now, no approval needed)

[300–400 words, per story-framework.md]

## 2. Named case study (for client approval)

[500–700 words, with the at-a-glance box. `[client quote to add]` where the quote goes if there isn't one yet. Or: "Skipped: you said this client can never be named. Use the unbranded story."]

## 3. Approval pack

**Approval email**
[filled in from approval-pack.md]

**Questions to get a real quote**
[the 5 questions, adjusted for this client's industry]

**After they reply**
[the short next-steps list]

## 4. Repurposing pack

**LinkedIn post 1: the story**
[ ]

**LinkedIn post 2: the lesson**
[ ]

**LinkedIn post 3: the result**
[ ]

**Proof snippet** (for emails and proposals)
[ ]

**One-slide summary**
[Headline]
- Challenge: [ ]
- What we did: [ ]
- Result: [ ]

**Website card**
[Headline]
[2 sentences]

## Next steps

1. Send the approval email this week.
2. Add the story to your Case Study Library and note where you use it.
3. Got another project? Do the next one. Three to five stories across different industries or services gives buyers someone like them to relate to.

---

*This case study is part of the Centurion Strategy (Attract, Engage, Convert) by Emergence Digital.*
