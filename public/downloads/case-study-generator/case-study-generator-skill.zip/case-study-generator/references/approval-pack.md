# Approval Pack

For the named case study. Fill these in for the project and include them in the output. Same copy rules as everything else.

## 1. The approval email (under 120 words)

Write a short, friendly email from the user to their client contact. It must:
- Thank them for the project, mentioning one specific thing that went well
- Say what you'd like to publish and where (from question 9b)
- Attach or link the draft, and say **they have the final say** on wording, and can stay unnamed if they prefer
- Ask for one or two sentences in their own words, or offer a 15-minute call to get them. **If they've already said something good** (question 7), quote it back and ask if you can use it instead
- Give a gentle timeframe ("If you could let me know by [date]…")

Structure to follow:

> Subject: A quick favour about [project]
>
> Hi [Client first name],
>
> [One line thanks, specific to the project.]
>
> We'd like to share the story of [project] as a case study on our [website / proposals]. I've attached a draft. You have the final say on every word, and we can keep [Client company] unnamed if you'd prefer.
>
> Would you be happy to add a sentence or two in your own words about [what changed]? Or if it's easier, I can grab 15 minutes with you and write it up for you to approve.
>
> If you could let me know by [date], that would be great.
>
> [Sender]

## 2. Questions to get a real quote

Five questions for an email or a 15-minute call. Open-ended, so the answers sound like them:

1. What was it like before we started? What was frustrating?
2. What made you decide to do something about it then?
3. What's different now, day to day?
4. What would you tell another [industry] firm thinking about doing the same?
5. Is there anything about working with us that surprised you?
6. Have you measured the difference? For example, time saved, costs, revenue or deals won. (Only ask this if the user had no hard numbers.)

Tell the user: **use their answers word for word** (trimmed, not rewritten), and send the final quote back to the client to approve before publishing.

## 3. What to do after they reply

- **Yes, named:** add their quote, send the final version back for sign-off, then publish. Update the library: Approved → Published.
- **Yes, but unnamed:** publish the unbranded story with their quote attributed by role and profile ("Practice Manager, Brisbane wealth firm").
- **No:** keep using the unbranded story, which never needed approval.
- **No reply after 2 weeks:** one short follow-up, then move on.
