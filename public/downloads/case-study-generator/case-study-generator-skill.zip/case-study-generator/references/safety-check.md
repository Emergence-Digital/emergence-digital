# Safety Check

Run this on every piece before handing over. Case studies for IT and security work can identify a client or hand an attacker a roadmap without meaning to.

## For the unbranded story, the posts, the snippet and the card

Remove or generalise anything that could identify the client:
- [ ] Client name, brand, product names, logos, or staff names and titles that point to one person
- [ ] Exact location if it narrows it to one firm (use the city or region, not the suburb or building)
- [ ] Unique facts that give it away (e.g. "the only insurer on the Sunshine Coast with 70 staff", a specific award, a named merger partner)
- [ ] Exact dates (use "recently" or the year)

## For every piece, including the named case study

Remove or generalise anything that could help an attacker:
- [ ] Specific vulnerabilities, weaknesses or gaps that may still exist
- [ ] Security tools, versions and configurations ("MFA" is fine; product names and settings are not)
- [ ] System architecture, network details, IP ranges, hostnames
- [ ] Incident details that aren't already public (how an attacker got in, what was taken)
- [ ] Exact dates of incidents or when protections were switched on

## Also check

- [ ] Every quote is the client's real words, exactly as given
- [ ] Every number came from the user's answers or pasted material
- [ ] Nothing claims more than the user said (no "zero risk", "fully secure", "guaranteed")

If anything was removed, list it briefly in the output ("Removed for safety: the name of the security tool, the exact incident date") so the user knows why.
