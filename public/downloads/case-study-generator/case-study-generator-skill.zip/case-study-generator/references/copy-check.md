# Copy Check

Run on every piece. **Count; don't eyeball.** If anything fails, rewrite that piece and check again. Keep the checks behind the scenes: don't show a pass table, word counts or failed drafts, and don't mention the checks unless the user asks. They only see the finished result.

## Counted checks

| Check | Pass if |
|---|---|
| Length | Within the range for that piece in `story-framework.md` |
| Em dashes (—) and en dashes used as dashes (–) | 0 |
| Exclamation marks | 0 |
| Sentences over 25 words | 0 |
| Banned phrases (list below) | 0 |
| A specific result | At least 1 number or concrete change in the story, case study, result post and snippet (or a `[result to confirm]` placeholder) |
| Quotes | Every piece of text in quotation marks matches the client's words exactly, or is a placeholder |

## Banned phrases

Case study clichés and AI tells. Check case-insensitively.

- leading provider / leading partner / trusted partner / trusted advisor
- partnered with (use "worked with")
- journey / transformation journey / digital transformation journey
- seamless / seamlessly / robust / holistic / cutting-edge / state-of-the-art / best-in-class / world-class / industry-leading
- leverage / unlock / unleash / empower / supercharge / elevate / streamline (as a vague claim)
- game-changer / game changing / revolutionise
- in today's fast-paced / ever-evolving / digital landscape
- delve / navigate the complexities / at the end of the day
- here's the kicker / here's the thing / the result? / the best part?
- it's not X, it's Y / not just X, but Y
- exceeded expectations / above and beyond / went the extra mile
- solutions (as a vague noun on its own, e.g. "our solutions")

## Read-through checks

After the counted checks pass, read each piece once as the buyer:

- **Would a buyer at a similar firm see themselves in it?** If the client profile or challenge is vague, sharpen it.
- **Is the headline a result, not a service?**
- **Is "what was done" written as change for the client, not a list of deliverables?**
- **Is every claim backed by an answer or the pasted material?** Remove it or mark it `[to confirm]`.
