# Story Framework

Every piece follows the same arc: **result first, then challenge → what was done → results → what it means for the reader.** Buyers read case studies to see a firm like theirs, with a problem like theirs, get a result they want.

## The pieces

| Piece | Length | Structure |
|---|---|---|
| Unbranded client story | 300–400 words | Headline result · client profile (one line) · the challenge · what was done · the results · what this means for you · call to action |
| Named case study | 500–700 words | Headline result · at-a-glance box (client, industry, size, service, result) · the challenge · why they chose you · what was done · the results · client quote · what this means for you · call to action |
| LinkedIn post 1: the story | 120–200 words | A hook line with the result · the situation · what changed · one question to the reader |
| LinkedIn post 2: the lesson | 120–200 words | One thing the project taught you that other firms like the client should know · how to apply it |
| LinkedIn post 3: the result | 60–120 words | The before and after in plain numbers or plain change · one line on how |
| Proof snippet | 40–60 words | For emails and proposals: client profile, problem, what changed. One or two sentences. |
| One-slide summary | Headline ≤ 10 words + 3 bullets ≤ 15 words each | Headline result · Challenge · What we did · Result |
| Website card | Headline ≤ 10 words + 2 sentences ≤ 40 words in total | For a case study list or homepage |

## Writing rules

- **Headline = the result**, in their terms: "One system for two offices, in one weekend", not "Managed IT services for a wealth firm".
- **Describe the unbranded client by profile:** industry, size and location ("a 45-person wealth firm in Brisbane"). Never a name, logo, staff names or anything unique enough to identify them (see `safety-check.md`).
- **The challenge in their language.** What it felt like for their people, not technical jargon.
- **What was done = what changed for them,** not a list of deliverables or tools. Keep technical detail to what a buyer needs to believe it.
- **Results:** real numbers first, as before and after where possible ("restores went from 4 hours to 45 minutes"). Lead with money results (revenue, cost, pipeline) if there are any, then time and operations, then risk and compliance, then the day-to-day difference.
- **Evidence matters.** Numbers from the client's data, your monitoring or invoices, or the client's own words (5d: a, b or c) can be stated as fact. A number that's your estimate (5d: d) must say so ("an estimated 10 hours a week") and never goes in a headline.
- **Never round up, combine or invent a number.** If there's no number, describe the change plainly ("staff now work from one system").
- **Numbers that don't fit together** (see the check in `questions.md`) are used as given and listed under "To confirm before publishing", with the reason in one line.
- **"What this means for you":** one or two sentences linking the story to the reader's situation (the buyer from question 9).
- **Call to action:** one, simple. For example: "If this sounds like your firm, let's talk."
- **Quotes:** only the client's real words, exactly as given. If none, put `[client quote to add]` in the named version only.
- **No client quote in the unbranded story** unless they answered 8a (approved). Their words, even unnamed, need their OK. Describe the change in your own words instead.
- **"Why they chose you"** comes from question 6b. If it wasn't answered, leave that section out of the named case study rather than guessing.
- **The "nearly went wrong" moment** (question 6), if given, goes in the "what was done" section. It makes the story believable.
- Short paragraphs of 1 to 3 sentences.
