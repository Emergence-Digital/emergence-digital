# Copy Check

Run every check on every email. **Count; don't eyeball.** If anything fails, rewrite that email and check it again. Keep the checks behind the scenes: don't show a pass table, word counts or failed drafts, and don't mention the checks unless the user asks. They only see the finished result.

## Counted checks

| Check | Pass if |
|---|---|
| Word count | Within the range for that email in `seven-c-framework.md` (body only, excluding sign-off) |
| You vs we | Count of "you" + "your" is greater than count of "we" + "our" + "us" + "I" + "my" |
| Em dashes (—) and en dashes used as dashes (–) | 0 |
| Exclamation marks | 0 |
| Questions | Exactly 1 call to action or question at the end (a second question elsewhere is fine only in email 6) |
| Links | 0 in email 1; at most 1 in any other email |
| Sentences over 25 words | 0 |
| Banned phrases (list below) | 0 |

## Banned phrases

These make an email sound templated or AI-written. Check case-insensitively.

- I hope this email finds you well / I hope you're well / hope all is well
- My name is
- just following up / just checking in / circling back / touching base / bumping this
- I wanted to reach out / reaching out because
- quick question (as a subject or opener)
- here's the kicker / here's the thing / the result? / the best part?
- it's not X, it's Y (and "not just X, but Y")
- game-changer / game changing / cutting-edge / revolutionise / transform your
- unlock / unleash / supercharge / elevate / empower / leverage / seamless / robust / holistic / synergy
- in today's fast-paced / in today's digital landscape / ever-evolving
- delve / navigate the complexities / at the end of the day
- don't hesitate to reach out / feel free to
- I'd love to / we'd love to
- solutions (as a noun on its own, e.g. "our solutions")
- best-in-class / world-class / industry-leading / trusted partner

## Read-through checks

After the counted checks pass, read each email once as the buyer and check:

- **Does the first line sound like it was written for them?** If it could go to any company, rewrite it.
- **Is there a claim that isn't backed up?** Remove it or mark it `[to confirm]`.
- **Is it describing deliverables or process?** Rewrite it as what changes for the client.
- **Would a busy Head of IT or CFO read it on their phone in 15 seconds?** If not, cut it.
- **Does it match their voice** (if they pasted sample emails)? Greeting, sign-off and sentence length should feel the same.
