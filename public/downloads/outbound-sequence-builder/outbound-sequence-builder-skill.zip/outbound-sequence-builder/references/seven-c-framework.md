# The 7C Sequence

Seven emails over about four weeks. Each email leads with one C. Every email still stands on its own, because most people only read one or two.

Send days are **business days** after the first email. Send each follow-up as a reply in the same thread for emails 2 to 4 and 6 to 7 (subject starts with "Re:" automatically), and as a new thread for emails 1 and 5. This keeps the conversation together but gives the call to action a fresh start.

| # | C | Send day | Length | Job of this email |
|---|---|---|---|---|
| 1 | **Challenge** | 0 | 60–100 words | Name the problem their trigger creates, in their words. Show you understand their world. Soft ask. |
| 2 | **Credibility** | 2 | 50–80 words | Why you're worth listening to: certifications, partner status, the kinds of firms you work with. One or two facts, not a list. |
| 3 | **Capability** | 5 | 60–90 words | How you'd solve it. Describe what changes for them, not your process or deliverables. |
| 4 | **Case study** | 8 | 70–110 words | One client story: before, what you did, after. Unbranded is fine. Real only. |
| 5 | **Call to action** | 12 | 40–70 words | The clearest, easiest ask. Make it low-risk: a 15-minute call, a free check, a specific time. |
| 6 | **Check-in** | 16 | 25–50 words | A short, human nudge. Add one new useful thing (a stat, a question, a resource), never "just following up". |
| 7 | **Close-out** | 21 | 25–45 words | A polite final email that gives them an easy out ("not a priority right now?"). This often gets the most replies. |

## Rules for every email

- **Open on them.** First line is the `[Opening line]` (email 1) or about their situation (emails 2 to 7). Never "I hope this finds you well" or "My name is…".
- **One ask.** One question or call to action per email, at the end. Emails 1 to 4 use a soft, interest-based ask ("Worth a conversation?", "Is this on your radar?"). Email 5 makes the direct ask.
- **Plain text.** No images, no attachments, no tracking-heavy links. At most one link, and none in email 1.
- **Subject lines:** 2 to 5 words, lowercase or sentence case, specific to them (e.g. "audit prep at [Company]"). No clickbait, no "Re:" tricks on new threads, no emojis.
- **Short paragraphs:** 1 or 2 sentences each, so it reads well on a phone.
- **Sign-off:** first name, title, company, phone. Then the unsubscribe line (see `send-checklist.md`).

## Opening lines

The `[Opening line]` is one sentence about something real and recent at their company, tied to the trigger. It should be checkable in 2 minutes on their website, LinkedIn company page or the news.

Formulas by trigger:
- **Growth or new sites:** "Saw [Company] has just opened [new site / merged with X]."
- **New leader:** "Noticed [Company] welcomed a new [CFO / Head of IT] recently."
- **Incident in their industry:** "With [incident at a similar firm] in the news, I imagine data security is on the agenda at [Company]."
- **Audit or regulation:** "With [regulation / deadline] coming up, most [industry] firms we speak to are…"
- **Costs:** "A lot of [industry] firms your size are seeing Microsoft and Azure costs climb this year."

Never use personal details (family, holidays, personal social posts). Company-level facts only.

**Relevant or nothing:** the fact must lead into the problem the email is about. An unrelated fact (an award, a sponsorship, a compliment) makes the email feel more templated, not less. If there's no relevant fact, use an industry opener ("Most [industry] firms your size…") instead.
