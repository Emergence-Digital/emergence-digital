# Output Template

Use this structure. Replace everything in [brackets]. Mark anything unconfirmed as `[to confirm]` and list it at the top.

---

# Outbound Sequence: [Firm name]

*Built with the Centurion Strategy Outbound Sequence Builder · [date]*

**To confirm before sending:** [list of placeholders, e.g. client result numbers, permission to name a client. Or "Nothing, ready to go."]

## Campaign at a glance

| | |
|---|---|
| Writing to | [buyer, e.g. Head of IT at 35–100 staff insurance brokers] |
| Leading with | [trigger / problem] |
| Asking them to | [call to action] |
| Sent by | [name, title, company] |
| Length | 7 emails over about 4 weeks |

## The 7 emails

For each email:

### Email [n]: [C name] · Day [x] · [new thread / reply in thread]
**Subject:** [option 1]  ·  **Alternative:** [option 2]   *(emails 1 and 5 only; for the others write "sent as a reply in the same thread")*

[Body, using merge fields: [First name], [Company], [Opening line]]

[Sign-off: name, title, company, phone]
[Unsubscribe line]

*Why it works:* [one line]

## Opening lines for your target companies

*Company-level public information. Check each one is still true before sending.*

| Company | What we found | Opening line | Source |
|---|---|---|---|
| [ ] | [recent fact, or "nothing recent"] | [one sentence, marked "generic" if no fact found] | [link] |

[If there's no company list: 4 opening-line formulas for their trigger and "how to research an opening line in 2 minutes".]

### Email 1, ready to copy

[For each company: the full email 1 with its subject, opening line and company name filled in, and only [First name] left blank. Plain text block, sign-off included.]

## When they reply

*Reply within the hour if you can, and stop the sequence for anyone who replies.*

[A ready-to-send reply for each: 1 interested, 2 not now, 3 send me information, 4 what does it cost, 5 wrong person, 6 already have a provider, 7 unsubscribe. Each under 70 words, with one line on what to do next.]

## Before you hit send

[The send checklist, adjusted for them.]

## Next steps

1. Send to 20 to 30 of your best-fit companies first, then review.
2. Want a version for a different buyer or trigger? Ask.
3. "Not now" replies go into a nurture sequence (Centurion: Convert).

---

*This sequence is part of the Centurion Strategy (Attract, Engage, Convert) by Emergence Digital.*
