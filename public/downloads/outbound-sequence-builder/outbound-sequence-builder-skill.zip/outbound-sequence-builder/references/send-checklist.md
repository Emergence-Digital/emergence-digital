# Before You Hit Send

Include this as the last section of the output, adjusted for their situation. Keep it to one page.

## 1. Protect your main email address

- [ ] **Send from a separate domain** (e.g. `getyourcompany.com.au`, not your main domain), so a spam complaint can't hurt your everyday email.
- [ ] **Set up SPF, DKIM and DMARC** on that domain. Your IT team or email provider can check these in 10 minutes.
- [ ] **Warm up new inboxes** for 2 to 4 weeks before sending cold email (most sending tools have a warm-up feature).
- [ ] **Start small:** about 20 to 30 new people a day per inbox, and increase slowly. This is a common rule of thumb, not a hard limit.

## 2. Stay inside the Spam Act (Australia)

*This is a plain-English summary, not legal advice. Check the ACMA's guidance or a lawyer if you're unsure.*

- [ ] **Consent:** only email business addresses that are publicly listed (e.g. on their website) where your message relates to that person's role, and where they haven't said they don't want marketing emails.
- [ ] **Identify yourself:** every email includes your name, company and contact details.
- [ ] **Easy unsubscribe:** every email includes a way to opt out, e.g. "Not relevant? Reply 'no thanks' and I won't email again." Honour it within 5 business days, and never email them again from any address.
- [ ] **No tricks:** subject lines must not mislead (no fake "Re:" on a first email).

## 3. Clean your list

- [ ] **Verify email addresses** before sending (most sending tools include this). Keep bounces under about 2%.
- [ ] **Remove** current clients, open deals, competitors and anyone who's unsubscribed before.
- [ ] **Check every opening line** is true and current.

## 4. Know what good looks like

These are rough guides from outreach tool providers, not promises.

| Measure | Typical | Good |
|---|---|---|
| Reply rate (any reply) | 2–3.5% | 5–10% |
| Positive replies | about half of replies | |
| Bounce rate | under 2% | under 1% |

**When to change something:** after the full sequence has gone to 50 people. Fewer than 2 replies usually means the trigger or offer is wrong, not the wording. Change the angle before you rewrite the emails.

## 5. When they reply

Use the ready-to-send replies in the "When they reply" section. Reply within the hour if you can, stop the sequence for anyone who replies, and remove unsubscribes everywhere straight away.
