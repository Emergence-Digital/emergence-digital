# Reply Templates

Replies are where deals are won or lost. Include a "When they reply" section in the output with a reply for each situation below, written for their buyer, trigger and offer, in the same voice as the sequence. Keep each reply under 70 words, and run the same counted copy check on them (`copy-check.md`).

Rules for every reply:
- **Reply within the hour** if you can. Speed matters more than polish.
- **Answer what they asked first.** Then make one small next step.
- **Stop the sequence** for anyone who replies, whatever they say.

---

## 1. "Sounds interesting" / "Tell me more"

**Goal:** book the call while they're warm. Give two specific times and a booking link if they use one.

> Thanks [First name], glad it's useful. The quickest next step is a 15-minute call. You'll see [what they'll get, e.g. where your gaps are likely to be]. Would [day] at [time] or [day] at [time] suit you? Or pick a time that works for you here: [booking link]

## 2. "Not now" / "Maybe later"

**Goal:** get a date to come back, and move them into nurture.

> Thanks for letting me know, [First name]. Timing matters. When would suit you better, roughly? You won't hear from me until then, apart from the odd useful note on [topic] if you're happy to get it.

*Then:* set a reminder for the date they give, and add them to a nurture sequence (Centurion: Convert).

## 3. "Send me some information"

**Goal:** send something short and specific, not a brochure, and keep a next step.

> Sure, [First name]. Rather than a generic brochure, here's [one specific resource: a one-page checklist, a short case study] covering [what matters to them]. If it raises questions for you or your team, a 15-minute call is usually quicker than email. Just say when suits you.

## 4. "What does it cost?"

**Goal:** give a straight answer (a range or starting point), then tie it to their situation.

> Fair question. Most [clients like you] start at [price or range], depending on [the main thing that changes the price]. The 15-minute call is free and you'll come away with [what they get] either way, so you can judge whether it's worth it. Would [day] work?

*If they won't share prices:* say what the price depends on and offer the call to give a real number. Never dodge the question entirely.

## 5. "I'm not the right person"

**Goal:** get a referral, and thank them.

> Thanks [First name], appreciate you letting me know. Who would be the best person to speak to about [topic] at [Company]? I'll mention you pointed me their way, if that's OK.

*Then:* email that person, open with "[First name] suggested I get in touch", and start the sequence fresh.

## 6. "We already have a provider"

**Goal:** respect it, and leave a door open without bad-mouthing anyone.

> Makes sense, [First name], and good to hear you're covered. If you ever want a second opinion on [specific thing, e.g. your next audit], just reply here. No strings. All the best with it.

## 7. "Not interested" / "Unsubscribe"

**Goal:** confirm and remove. No persuasion. This is required under the Spam Act.

> Done, [First name]. You're off every list and you won't hear from me again. All the best.

*Then:* remove them from every list straight away (within 5 business days at most) and never email them again from any address.
