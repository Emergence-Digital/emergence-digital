# Planning Rules

How to turn their answers into a 4-week calendar. Work through these in order.

## 1. Fit the plan to their time first

A calendar they can't keep up with gets abandoned in week 2. Size the plan to the time they have (question 7a) before choosing a single topic.

**Time per post** (starting guesses for writing, making and scheduling one post; the same numbers are in the spreadsheet's Settings tab):

| Format | Minutes |
|---|---|
| Text | 20 |
| Poll | 10 |
| Image | 40 |
| Carousel or PDF | 90 |
| Short video | 90 |
| Article | 120 |
| Long video | 240 |

Count every post at full time, even when it reuses an idea. That keeps the plan on the safe side and matches the spreadsheet's Summary tab.

**Time available** for each answer to 7a: a) 45 minutes, b) 90 minutes, c) 180 minutes, d) 300 minutes a week. Plan to use no more than this.

**If what they asked for doesn't fit, scale it back in this order:**
1. Keep their main platform (where their buyers are; for most IT businesses selling to other businesses, LinkedIn) at the frequency they asked for, if it fits.
2. Reuse one idea across platforms instead of making separate posts.
3. Swap heavy formats for lighter ones (a carousel becomes an image with a strong caption).
4. Reduce frequency on the other platforms.
5. Drop a platform only as a last resort, and say why.

Tell them what you changed in one or two plain lines. Never quietly give them less than they asked for.

**If they have more time than the plan needs,** don't fill it. Suggest using the spare time to reply to comments and comment on their buyers' posts, which builds relationships faster than posting more.

## 2. How often, if they're not sure

Starting points that most small teams can keep up with. Consistency matters more than volume.

| Platform | Starting point |
|---|---|
| LinkedIn (personal profile) | 2 to 3 a week |
| LinkedIn (company page) | 1 to 2 a week |
| Facebook | 2 a week |
| Instagram | 2 a week |
| YouTube | 2 a month |
| TikTok | 2 a week |
| X | 3 a week |

Then apply rule 1.

## 3. Whose name it goes under

- **Personal profiles** (question 3b or c) are where most B2B conversations start. Put the strongest ideas there: opinions, lessons and client stories.
- **Company pages** carry proof, team posts, events and offers.
- If both, the personal post goes first and the company page shares a version later that week, not the same day.

## 4. The mix of post types

Every post has one job. Tag each one:

| Type | What it is | Starting share |
|---|---|---|
| Helpful | Tips, answers to questions clients ask, plain explanations | 60% |
| Proof | Client results, reviews, case studies | 20% |
| Behind the scenes | The team, how they work, what they're doing | 10% |
| Sales | Their offer, an event, an invitation to talk | 10% |

Adjust for their goals (question 2):
- **Leads:** move up to 20% sales and 25% proof, taken from helpful.
- **Trust:** keep proof at 20 to 25%.
- **Existing clients:** more helpful, fewer sales.
- **Hiring:** up to 25% behind the scenes.
- **Events:** plan event posts in the sales share: an announcement about 3 weeks out, a reminder 1 week out, a last call the day before, and a short recap afterwards.

Round to whole posts. The first post in the calendar is helpful. Never put two sales posts in a row on the same platform.

**Proof posts need real proof.** Only tag a post Proof if it uses a result, review or client story the user gave you. If they said they have client stories or reviews but gave no details, keep the Proof post and make its opening line a placeholder like `[client result to add]`, listed under "To fill in before posting". If they have none (question 9g), use Behind the scenes posts about how they work instead (e.g. "what happens in your first week with us").

## 5. Themes

Pick 3 to 5 themes from question 8 and their website. Name each in 2 to 5 words and use exactly those names in the calendar and the spreadsheet. A theme is a topic they want to be known for, written in their buyer's language ("keeping staff working when systems fail", not "BCDR"). Rotate themes so the same one doesn't run twice in a row on the same account. A company page sharing a version of a personal post later that week is fine.

## 6. Formats that suit each platform

Only use formats they said they can make (question 6).

| Platform | Formats that suit it |
|---|---|
| LinkedIn | Text, image, carousel or PDF, short video, poll, article |
| Facebook | Image, short video, text, event |
| Instagram | Image, carousel, short video. Captions can't hold clickable links, so use "link in bio". |
| YouTube | Long video, short video |
| TikTok | Short video only |
| X | Short text, image |

If a platform needs a format they can't make (TikTok without video), say so and leave it out, or suggest the smallest step that would make it work.

## 7. Reuse before you create

Start each week from one core idea and adapt it for each platform, with its own opening line. Use what they already have (question 9) first:
- A client story becomes a proof post, a lesson post and a short result post.
- A blog becomes a text post, a carousel and a poll.
- An event becomes the four event posts above.

## 8. Days and times

- Spread posts across the week. Two posts a week: Tuesday and Thursday. Three: Monday, Wednesday and Friday, or Tuesday, Wednesday and Thursday.
- Never two posts on the same platform on the same day.
- Business audiences: weekdays in business hours (early morning, lunchtime or late afternoon). Consumer or local audiences on Facebook and Instagram: evenings and weekends can work too.
- Times are suggestions. Tell them to check their own analytics after 4 weeks and move posts to when their audience responds. Don't quote statistics about the "best time to post".

## 9. Dates

Use `key-dates.md` and their own dates (question 10). Only include dates their audience would care about, and no more than one date-based post a week. Avoid planning sales posts over the Christmas to New Year break, when most business buyers are away.

## 10. Length and start

The calendar covers 4 weeks from the start date (question 11). If they didn't give one, start on the next Monday.

## 11. Things to avoid

- Anything from question 11.
- Client names, unless the user says the client has approved it.
- Security details that could help an attacker: specific vulnerabilities, security tools and settings, system details, or details of incidents that aren't public.
- Claims they haven't given you: results, numbers, awards, certifications, review counts or guarantees. Use a placeholder instead.
