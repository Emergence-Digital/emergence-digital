# Deck Rules

The deck lays this skill's output out as slides on Emergence Digital's template. It is useful information to read and share, not a talk someone gives, and not a pitch. The skill's own SKILL.md lists which slides to use.

## Make it

1. Write the content to `deck.json`:
   `{"skill": "[this skill's name]", "client": "[their company name]", "date": "[Month YYYY]", "deck_title": "[from the skill]", "slides": [...]}`
   The slide types and their fields are listed at the top of `scripts/make_deck.py`.
2. Run `python3 scripts/make_deck.py deck.json assets/Deck-Template.pptx [file name from the skill]`. If python-pptx is missing, run `pip install python-pptx` first.
3. Give them the .pptx file. Don't show them the deck.json.

## Write the slides

- Use the slides the skill lists, in that order. Don't add quote, statistics, speaker notes or call-to-action slides of your own.
- Titles are plain labels for what's on the slide, like the headings in the output. Use the eyebrows and titles the skill gives, putting their company name where it says [company].
- No slogans, claims, promises or calls to action on the content slides: no "that land", no "Let's", no "Win them…", no exclamation marks.
- The cover: write the title and a one-sentence intro saying what the deck covers. The script adds their company name and the month.
- The last slide is always `{"type": "next_steps"}`: Emergence Digital's closing slide. The script fills in its title, line, booking button, link and email. Don't add fields to it or change it.
- Keep the text short so it fits the template: titles under 45 characters; summary paragraphs under 220 and points under 35; card text under 110; table cells under 70; step lines under 80; a `copy` slide's text under about 1,600 characters.
- Use only what's in the output. Never add a fact, number or quote that isn't there.

## Missing information

The deck only shows what the user told you and what you found. Work around anything missing instead of flagging it or filling it in:
- A column with nothing in it: leave that column out of the table.
- A row with nothing in it: leave that row out.
- Fewer items than a cards slide holds: give it just the ones you have (1 to 3 cards).
- Numbers you don't have: show what you do have in words, with the columns renamed to fit.
- A slide with nothing at all for it: leave the slide out, and drop or reword its line on the Contents slide so it still matches.
- Never write "unknown", "not given", "TBC" or a guess into a slide, and don't add a slide listing what's missing.
- Emails and posts shown in full (`copy` slides) stay exactly as written in the output, including merge fields like [First name] and any placeholder the user still has to fill in. To show a heading inside one (like "What we did" in a story), put it on its own line wrapped in `**`.
