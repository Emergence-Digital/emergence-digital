# Writing the Posts

Every post in the calendar gets a topic, an opening line and a call to action. Week 1 gets the full post, ready to copy.

## Topics

- Write each topic as what the reader gets, not what the business does: "What to do in the first hour of an outage", not "Our incident response service".
- Make it specific to their buyer (question 1). "Three settings every accounting firm should check before tax time" beats "Cyber security tips".

## Opening lines

The opening line is what people see before "see more". It decides whether the rest gets read.

- Under 15 words.
- About the reader's situation, a clear opinion, or a specific moment. Not about the business.
- No questions that can be answered "no" ("Are you worried about cyber security?").
- No clickbait or false urgency.

Patterns that work:
- A moment they'll recognise: "Systems down at 9am on a Monday. Here's the first hour."
- A plain opinion: "A backup you've never restored is a guess."
- A specific result (only one the user gave you): "A 45-person firm got 4 hours a day back."
- A mistake to avoid: "Most firms check their backups. Few check they can restore them."

## Calls to action

One per post: something the reader does (comment, save, share, read, book), not an instruction like "review your priorities". Match it to the post type:
- **Helpful:** a comment, a save, or a question back ("Which of these have you checked?")
- **Proof:** read the full story, or see more reviews
- **Behind the scenes:** say hello, or meet the team
- **Sales:** book a call, register for the event, or reply to ask

Only sales posts ask for a call or a booking.

## Full posts for week 1

| Platform | Length | Notes |
|---|---|---|
| LinkedIn | 80 to 200 words | Short paragraphs of 1 to 2 sentences. 0 to 3 hashtags at the end. Links go in the first comment. |
| Facebook | 40 to 120 words | Warmer and more local. 0 to 2 hashtags. |
| Instagram | 50 to 150 words | The image does the work; the caption backs it up. 3 to 5 relevant hashtags. "Link in bio" for links. |
| X | Under 280 characters | One idea. |
| Short video (any platform) | Script of 60 to 120 words | The first spoken line, 3 short points, the call to action, plus a caption of up to 50 words. |
| Long video | Outline | Title, the hook in the first 15 seconds, 3 to 5 sections, the call to action. |
| Carousel or PDF | Slide list | 5 to 8 slides: a title slide, one point per slide, a final slide with the call to action. Plus a caption of 40 to 100 words. |
| Image | Image idea plus caption | Say what the image shows (e.g. "photo of Sam at the help desk"), then the caption. |
| Poll | Question plus 2 to 4 options | Plus a caption of 20 to 60 words. |

Use their tone (question 12). Use Australian spelling and plain, professional English, with no slang ("G'day", "mate", "no worries").

## Copy check

Run on every opening line and every week 1 post **by counting, not eyeballing**. If anything fails, rewrite it and check again. Keep the checks behind the scenes: don't show a pass table, word counts or failed drafts, and don't mention the checks unless the user asks. They only see the finished result.

| Check | Pass if |
|---|---|
| Length | Within the range for that platform or format above |
| Opening lines | Under 15 words |
| Em dashes (—) and en dashes used as dashes (–) | 0 |
| Exclamation marks | 0 |
| Sentences over 25 words | 0 |
| Banned phrases (list below) | 0 |
| Reader focus | "you" and "your" appear at least as often as "we", "our" and "us" |
| Claims | Every result, number, review or client detail came from the user. Otherwise it's a placeholder. |
| Calls to action | Exactly one per post, and only sales posts ask for a call or booking |

### Banned phrases

Check case-insensitively.

- in today's fast-paced / ever-evolving / digital landscape / in this day and age
- game-changer / game changing / revolutionise / next level
- leverage / unlock / unleash / empower / supercharge / elevate / streamline (as a vague claim)
- seamless / robust / holistic / cutting-edge / state-of-the-art / best-in-class / world-class / industry-leading
- delve / navigate the complexities / at the end of the day
- here's the kicker / here's the thing / the result? / the best part? / let that sink in / read that again
- it's not X, it's Y / not just X, but Y / "X, not Y" contrasts (e.g. "start with decisions, not software")
- trusted partner / trusted advisor / leading provider / our solutions
- I'm excited to announce / I'm thrilled to share / humbled to
- agree? / thoughts? (as the whole call to action)
- don't miss out / act now / limited time (unless there's a real deadline the user gave)
