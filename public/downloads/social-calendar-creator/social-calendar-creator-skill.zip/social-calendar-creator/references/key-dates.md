# Key Dates

Dates that often matter to IT businesses and their clients in Australia. Only use the ones their audience would care about. Dates marked "check" move each year: tell the user to confirm the date before posting, rather than stating one.

| When | Date | Good for |
|---|---|---|
| 28 January | Data Privacy Day | A helpful post on protecting client data |
| February (check) | Safer Internet Day | Staff awareness, scams, family-friendly online safety |
| 8 March | International Women's Day | Team posts, only if they have something genuine to say |
| 31 March | World Backup Day | Backups and restore testing |
| May or June (check) | Privacy Awareness Week (OAIC) | Privacy obligations, handling personal information |
| Late May to 30 June | End of financial year | Budget decisions, buying before 30 June, planning for the new year |
| 1 July | New financial year | Planning, reviews, new budgets |
| Late August (check) | Scams Awareness Week (ACCC) | Spotting scams, protecting staff and clients |
| Second Thursday of September | R U OK? Day | Team and culture posts |
| October | Cyber Security Awareness Month | Simple security steps, one per week |
| December | Before the Christmas break | Security and backup checks before staff log off; thank-you posts |
| Late December to mid January | Christmas and New Year | Lighter posting; no sales posts. Plan January's first posts to go out once business buyers are back. |

## Dates from their clients' industries

Ask what matters to the people they want to reach (question 1), and add those. For example:
- Accounting and finance: tax time (July to October), end of financial year
- Education: school terms and holidays
- Healthcare: accreditation periods
- Retail and hospitality: peak trading periods
- Construction and trades: the end-of-year shutdown

Never invent a date. If you're not sure of one, leave it out or mark it "check".
