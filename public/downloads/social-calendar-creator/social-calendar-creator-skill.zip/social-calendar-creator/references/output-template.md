# Output Template

Use this structure. Replace everything in [brackets]. Show only the finished plan: no checks, workings or drafts.

---

# Your social calendar: [start date] to [end date]

*Built with the Centurion Strategy Social Calendar Creator · [date]*

**To fill in before posting:** [placeholders, e.g. a client review, a photo of the team, an event link. Or "Nothing, ready to go."]

## Your plan at a glance

| Platform | Posted as | Posts a week | Formats | Days and times to start with |
|---|---|---|---|---|
| [LinkedIn] | [Personal profile] | [3] | [Text, carousel] | [Mon, Wed, Fri at 8:30 am] |

**Time needed:** about [X] hours a week, against the [Y] you have.
**Mix:** [7] helpful, [3] proof, [1] behind the scenes, [1] sales.

[Only if you scaled the plan back: **What I changed:** one or two plain lines on what and why.]

## Your themes

1. **[Theme]:** [one line on what it covers, in the buyer's words]
2. ...

## The calendar

### Week 1: [Mon date] to [Sun date]

| Date | Time | Platform | Posted as | Format | Theme | Post type | Topic | Opening line | Call to action |
|---|---|---|---|---|---|---|---|---|---|
| [1 Dec 2026] | [8:30 am] | [LinkedIn] | [Personal profile] | [Text] | [Theme] | [Helpful] | [ ] | [ ] | [ ] |

[Weeks 2 to 4 in the same format. Write dates as "1 Dec 2026" and times as "8:30 am", so the table pastes straight into the spreadsheet's Posts tab: week 1 at cell A6, each following week directly underneath.]

## Week 1, ready to post

### [Day, date]: [Platform], [format]

[The full post, script, slide list or poll, per `post-writing.md`. For images, start with "Image: [what it shows]".]

[Repeat for every week 1 post.]

## Dates in this period

[Only the dates used in the calendar, each with one line on why it's there. Leave this section out if none apply.]

## Making it happen

1. **Block one time slot a week** to write and schedule the next week's posts. LinkedIn lets you schedule a post when you create it, and Meta Business Suite schedules Facebook and Instagram.
2. **Spend 10 minutes a day replying** to comments and commenting on your buyers' posts. That's where conversations start.
3. **After 4 weeks, check your analytics.** Keep what got a response, drop what didn't, and move posts to the times your audience is most active. Then ask me for the next 4 weeks.

---

*This calendar is part of the Centurion Strategy (Attract, Engage, Convert) by Emergence Digital.*
