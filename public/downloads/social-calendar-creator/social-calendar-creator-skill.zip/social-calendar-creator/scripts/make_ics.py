"""Turns the posting plan into a calendar file (.ics) for Google Calendar, Outlook or Apple Calendar.
Each post becomes a 30-minute reminder at its posting time, with the topic, opening line and call to action.
Standard library only.

Usage: python3 make_ics.py posts.csv social-calendar.ics
posts.csv needs a header row with: Date (YYYY-MM-DD), Time (HH:MM, 24-hour; blank = 09:00), Platform,
Posted as, Format, Topic, Opening line, Call to action. Extra columns are ignored.
"""
import csv, sys, datetime, uuid

def esc(text):
    return (text or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

def fold(line):
    """Fold lines longer than 75 octets, as the iCalendar format requires."""
    out, raw = [], line.encode("utf-8")
    while len(raw) > 75:
        cut = 75 if not out else 74
        while (raw[cut] & 0xC0) == 0x80:  # don't split a multi-byte character
            cut -= 1
        out.append(raw[:cut].decode("utf-8")); raw = raw[cut:]
    out.append(raw.decode("utf-8"))
    return "\r\n ".join(out)

def main(src, dst):
    stamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Emergence Digital//Social Calendar Creator//EN",
             "CALSCALE:GREGORIAN", "X-WR-CALNAME:Social posting calendar"]
    count = 0
    with open(src, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if not (row.get("Date") or "").strip():
                continue
            day = datetime.date.fromisoformat(row["Date"].strip())
            hh, mm = ((row.get("Time") or "").strip() or "09:00").split(":")[:2]
            start = datetime.datetime.combine(day, datetime.time(int(hh), int(mm)))
            end = start + datetime.timedelta(minutes=30)
            platform = (row.get("Platform") or "").strip()
            summary = f"Post on {platform}: {(row.get('Topic') or '').strip()}"
            desc = "\n".join(x for x in [
                f"{platform} ({(row.get('Posted as') or '').strip()}), {(row.get('Format') or '').strip()}",
                f"Opening line: {(row.get('Opening line') or '').strip()}",
                f"Call to action: {(row.get('Call to action') or '').strip()}",
            ] if x.split(": ", 1)[-1])
            lines += ["BEGIN:VEVENT", f"UID:{uuid.uuid4()}@emergencedigital.com.au", f"DTSTAMP:{stamp}",
                      f"DTSTART:{start:%Y%m%dT%H%M%S}", f"DTEND:{end:%Y%m%dT%H%M%S}",
                      fold(f"SUMMARY:{esc(summary)}"), fold(f"DESCRIPTION:{esc(desc)}"),
                      "BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:Time to post", "TRIGGER:-PT15M", "END:VALARM",
                      "END:VEVENT"]
            count += 1
    lines.append("END:VCALENDAR")
    with open(dst, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(lines) + "\r\n")
    print(f"saved {dst} ({count} posts)")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
