#!/usr/bin/env python3
"""Turn a lead magnet's output into a deck built on the Emergence Digital master template.

One script for all four skills. The master copy lives in lead-magnets/tools/deck/; package.sh copies it
into each skill's scripts/ folder, so edit it there, not in a skill.

Usage:
    python3 scripts/make_deck.py deck.json assets/Deck-Template.pptx output.pptx

deck.json:
{
  "skill": "icp-generator",          (or outbound-sequence-builder, case-study-generator, social-calendar-creator)
  "client": "DPC Services Group",
  "date": "November 2026",
  "deck_title": "DPC Services Group ICP",
  "slides": [ {"type": "...", ...}, ... ]
}

Slide types (each copies one design from the template):
  cover        title, intro (the client's name and the month are filled in; eyebrow and payoff override them)
  agenda       title, items: [[heading, line], ...]  (up to 6)
  section      eyebrow, title, line
  text         eyebrow, title, paragraphs: [one, two], label, points: [...]  (up to 4 points)
  copy         eyebrow, title, heading, text, note  (a full email or post: heading is an optional bold first line, like
               the subject; in text, new lines start new paragraphs, a blank line adds space and a line wrapped in
               ** is bold (for headings); note is a small line
               at the bottom; the type gets smaller to fit, so keep text under about 1,600 characters)
  statement    eyebrow, title, payoff, line
  cards        eyebrow, title, cards: [[heading, text], ...]  (1 to 3; fewer share the width)
  steps        eyebrow, title, steps: [[heading, text], ...]  (up to 4)
  before_after eyebrow, title, left: {label, heading, points}, right: {label, heading, points}
  table        eyebrow, title, columns: [...], rows: [[...], ...], widths: [...] (optional)
  quote        eyebrow, quote, company, name, role
  next_steps   Emergence Digital's closing slide. Leave every field out to use the skill's CLOSING below;
               title, line, button, url and contacts: [[LABEL, value], ...] (up to 3) override it.

Needs python-pptx (pip install python-pptx).
"""
import copy
import json
import sys

from pptx import Presentation
from pptx.oxml.ns import qn
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu

# The closing slide's line for each skill. The rest of the slide is the same for all four.
CLOSING_LINES = {
    "icp-generator": "We’ll show you how to turn this ICP into qualified conversations every month.",
    "outbound-sequence-builder": "We’ll show you how to turn this sequence into qualified meetings every month.",
    "case-study-generator": "We’ll show you how to turn this story into more clients like this one.",
    "social-calendar-creator": "We’ll show you how to turn these posts into qualified conversations every month.",
}


def closing(skill):
    return {
        "title": "Let’s talk.",
        "line": CLOSING_LINES[skill],
        "button": "Book a Pipeline Scale Plan call",
        "url": "https://emergencedigital.com.au/pipeline-scale-plan-call"
               f"?utm_source=lead-magnet&utm_medium=claude-skill&utm_campaign={skill}",
        "contacts": [["Email", "contact@emergencedigital.com.au"]],
    }


TEMPLATE_INDEX = {"cover": 0, "agenda": 1, "section": 2, "text": 3, "copy": 3, "cards": 4, "numbers": 5, "statement": 6,
                  "quote": 7, "before_after": 8, "steps": 9, "table": 10, "image": 11, "next_steps": 12}


# ---------- slide copying ----------
def duplicate(prs, src):
    new = prs.slides.add_slide(src.slide_layout)
    for ph in list(new.placeholders):
        ph._element.getparent().remove(ph._element)
    src_bg = src._element.cSld.find(qn("p:bg"))
    if src_bg is not None:
        new._element.cSld.insert(0, copy.deepcopy(src_bg))
    tree = new.shapes._spTree
    for el in src.shapes._spTree.iterchildren():
        if el.tag in (qn("p:sp"), qn("p:graphicFrame"), qn("p:grpSp"), qn("p:cxnSp"), qn("p:pic")):
            tree.append(copy.deepcopy(el))
    return new


def drop_slides(prs, count):
    """Remove the first `count` slides (the template's own examples)."""
    sld_ids = prs.slides._sldIdLst
    for sld_id in list(sld_ids)[:count]:
        prs.part.drop_rel(sld_id.get(qn("r:id")))
        sld_ids.remove(sld_id)


# ---------- text helpers ----------
def shapes_by_name(slide):
    return {sh.name: sh for sh in slide.shapes}


def remove(shape):
    shape._element.getparent().remove(shape._element)


def set_text(shape, text):
    """Replace a shape's text, keeping the look of its first run."""
    tf = shape.text_frame
    paras = tf.paragraphs
    for p in paras[1:]:
        p._p.getparent().remove(p._p)
    p = paras[0]
    runs = p.runs
    if not runs:
        p.add_run()
        runs = p.runs
    for r in runs[1:]:
        r._r.getparent().remove(r._r)
    runs[0].text = str(text)


def set_points(shape, points):
    """Fill a bulleted text box with one paragraph per point, copying the first paragraph's style."""
    tf = shape.text_frame
    first = copy.deepcopy(tf.paragraphs[0]._p)
    body = tf._txBody
    for p in list(tf.paragraphs):
        body.remove(p._p)
    for i, point in enumerate(points):
        p = copy.deepcopy(first)
        if i == 0:
            spc = p.find(qn("a:pPr") + "/" + qn("a:spcBef"))
            if spc is not None:
                spc.getparent().remove(spc)
        runs = p.findall(qn("a:r"))
        for r in runs[1:]:
            p.remove(r)
        runs[0].find(qn("a:t")).text = str(point)
        body.append(p)


def footer(slide, deck_title, page):
    for sh in slide.shapes:
        if not sh.has_text_frame:
            continue
        t = sh.text_frame.text.strip()
        if t.startswith("Emergence Digital · "):
            set_text(sh, f"Emergence Digital · {deck_title}")
            sh.width = Emu(5486400)  # 6 in, so the footer stays on one line
        elif t.isdigit() and sh.top > 6000000:
            set_text(sh, page)
            # The template sizes the page number for one digit: widen it to the left so 10+ stays on one line.
            right = sh.left + sh.width
            sh.width = Emu(457200)
            sh.left = Emu(right - sh.width)
            sh.text_frame.paragraphs[0].alignment = PP_ALIGN.RIGHT


def fit_width(shape, text, inch_per_char, centre=False):
    """Widen a highlighted box so its text fits on one line (the template's highlight boxes are a fixed size)."""
    need = int(914400 * (inch_per_char * len(str(text)) + 0.4))
    if need > shape.width:
        mid = shape.left + shape.width // 2
        shape.width = Emu(need)
        if centre:
            shape.left = Emu(mid - need // 2)


def grow_cards(s, pairs, texts, chars_per_line=25, line_in=0.29):
    """Make all cards on a slide tall enough for the longest text (the card shapes don't grow by themselves)."""
    lines = max(-(-len(t) // chars_per_line) for t in texts)
    for card, body in pairs:
        bottom = s[body].top + int(914400 * (lines * line_in + 0.35))
        s[card].height = Emu(max(s[card].height, bottom - s[card].top))


def fill_copy(shape, text, width_in, height_in, heading=None):
    """Write a whole email or post into one box, one paragraph per line, at the largest size that fits."""
    lines = ([heading, ""] if heading else []) + text.split("\n")
    for size in (16, 15, 14, 13, 12, 11, 10):
        per_line = int(width_in / (size * 0.0071))  # Inter averages about 0.0064in per point; the rest allows for word wrap
        line_h = size * 1.3 / 72
        rows, gaps, blank = 0, 0, False
        for line in lines:
            if not line.strip():
                blank = True
                continue
            rows += max(1, -(-len(line) // per_line))
            gaps += blank
            blank = False
        if rows * line_h + gaps * size * 0.45 / 72 <= height_in:
            break
    tf = shape.text_frame
    first = copy.deepcopy(tf.paragraphs[0]._p)
    body = tf._txBody
    for p in list(tf.paragraphs):
        body.remove(p._p)
    blank = False
    for line in lines:
        if not line.strip():
            blank = True
            continue
        p = copy.deepcopy(first)
        for r in p.findall(qn("a:r"))[1:]:
            p.remove(r)
        r = p.find(qn("a:r"))
        bold = (heading and line is lines[0]) or (line.startswith("**") and line.endswith("**") and len(line) > 4)
        r.find(qn("a:t")).text = line[2:-2] if line.startswith("**") and line.endswith("**") and len(line) > 4 else line
        r.find(qn("a:rPr")).set("sz", str(size * 100))
        if bold:
            r.find(qn("a:rPr")).set("b", "1")
        ppr = p.find(qn("a:pPr"))
        ppr.find(qn("a:lnSpc")).find(qn("a:spcPts")).set("val", str(int(size * 130)))
        if blank and len(body.findall(qn("a:p"))):
            spc = ppr.makeelement(qn("a:spcBef"), {})
            spc.append(spc.makeelement(qn("a:spcPts"), {"val": str(int(size * 45))}))
            ppr.insert(1, spc)
        end = p.find(qn("a:endParaRPr"))
        if end is not None:
            end.set("sz", str(size * 100))
        body.append(p)
        blank = False


# ---------- table ----------
def fill_table(shape, columns, rows, widths=None):
    tbl = shape.table._tbl
    grid = tbl.find(qn("a:tblGrid"))
    trs = tbl.findall(qn("a:tr"))
    head_tr, body_trs = trs[0], trs[1:]
    total = sum(int(gc.get("w")) for gc in grid.findall(qn("a:gridCol")))
    ncol = len(columns)

    def fit_cells(tr):
        tcs = tr.findall(qn("a:tc"))
        while len(tcs) > ncol:
            tr.remove(tcs[-1])
            tcs = tr.findall(qn("a:tc"))
        while len(tcs) < ncol:
            tr.append(copy.deepcopy(tcs[-1]))
            tcs = tr.findall(qn("a:tc"))
        return tcs

    gcs = grid.findall(qn("a:gridCol"))
    for gc in gcs:
        grid.remove(gc)
    weights = widths or [1] * ncol
    for w in weights:
        gc = copy.deepcopy(gcs[0])
        gc.set("w", str(int(total * w / sum(weights))))
        grid.append(gc)

    # Smaller type for bigger tables, so it stays on the slide.
    n = len(rows)
    size = (1600 if n <= 4 and ncol <= 4 else 1300 if (n <= 6 and ncol <= 6) or (n <= 8 and ncol <= 4)
            else 1100 if n <= 9 else 1000)
    height = {1600: 510480, 1300: 400000, 1100: 340000, 1000: 310000}[size]

    def write(tc, value, sz):
        p = tc.find(qn("a:txBody")).find(qn("a:p"))
        runs = p.findall(qn("a:r"))
        for r in runs[1:]:
            p.remove(r)
        r = runs[0]
        r.find(qn("a:t")).text = str(value)
        r.find(qn("a:rPr")).set("sz", str(sz))
        lnspc = p.find(qn("a:pPr") + "/" + qn("a:lnSpc"))
        if lnspc is not None:
            lnspc.getparent().remove(lnspc)
        tcpr = tc.find(qn("a:tcPr"))
        tcpr.set("marT", "60000")
        tcpr.set("marB", "60000")
        tcpr.set("marL", "110000")
        tcpr.set("marR", "110000")

    for tc, v in zip(fit_cells(head_tr), columns):
        write(tc, v, size)
    head_tr.set("h", str(height))

    for tr in body_trs:
        tbl.remove(tr)
    for i, row in enumerate(rows):
        tr = copy.deepcopy(body_trs[i % len(body_trs)])
        tr.set("h", str(height))
        for tc, v in zip(fit_cells(tr), list(row) + [""] * (ncol - len(row))):
            write(tc, v, size)
        tbl.append(tr)
    shape.height = height * (n + 1)


# ---------- each slide type ----------
def build(slide, spec, deck):
    s = shapes_by_name(slide)
    t = spec["type"]
    if t == "cover":
        payoff = spec.get("payoff") or deck["client"]
        set_text(s["Text 0"], spec.get("eyebrow") or deck["date"].upper())
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], payoff)
        fit_width(s["Text 2"], payoff, 0.27)
        set_text(s["Text 3"], spec.get("intro", ""))
    elif t == "text":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        paras = spec.get("paragraphs", [])
        one, two = s["Text 2"], s["Text 3"]
        set_text(one, paras[0] if paras else "")
        # The template's boxes hold two lines each: make room for longer paragraphs (16pt, about 52 characters a line).
        lines = max(2, -(-len(paras[0]) // 52)) if paras else 2
        one.height = Emu(int(914400 * 0.33 * lines))
        if len(paras) > 1:
            set_text(two, paras[1])
            two.top = Emu(one.top + one.height + int(914400 * 0.2))
            two.height = Emu(int(914400 * 0.33 * max(2, -(-len(paras[1]) // 52))))
        else:
            remove(two)
        set_text(s["Text 4"], spec.get("label", "KEY POINTS").upper())
        points = spec.get("points", [])
        for i, (box, dot, txt) in enumerate([("Shape 5", "Shape 6", "Text 7"), ("Shape 8", "Shape 9", "Text 10"),
                                              ("Shape 11", "Shape 12", "Text 13"), ("Shape 14", "Shape 15", "Text 16")]):
            if i < len(points):
                set_text(s[txt], points[i])
                s[txt].width = Emu(s[box].left + s[box].width - s[txt].left - int(914400 * 0.15))
            else:
                for name in (box, dot, txt):
                    remove(s[name])
    elif t == "agenda":
        set_text(s["Text 1"], spec.get("title", "What we'll cover"))
        slots = [("Shape 2", "Text 3", "Text 4", "Text 5"), ("Shape 10", "Text 11", "Text 12", "Text 13"),
                 ("Shape 18", "Text 19", "Text 20", "Text 21"), ("Shape 6", "Text 7", "Text 8", "Text 9"),
                 ("Shape 14", "Text 15", "Text 16", "Text 17"), ("Shape 22", "Text 23", "Text 24", "Text 25")]
        items = spec["items"]
        for i, (line, num, head, sub) in enumerate(slots):
            if i < len(items):
                set_text(s[num], f"{i + 1:02d}")
                set_text(s[head], items[i][0])
                set_text(s[sub], items[i][1])
            else:
                for name in (line, num, head, sub):
                    remove(s[name])
    elif t == "section":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], spec.get("line", ""))
    elif t == "statement":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], spec.get("payoff", ""))
        fit_width(s["Text 2"], spec.get("payoff", ""), 0.42, centre=True)
        if spec.get("line"):
            set_text(s["Text 3"], spec["line"])
        else:
            remove(s["Text 3"])
    elif t == "copy":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        for name in ("Text 4", "Shape 5", "Shape 6", "Text 7", "Shape 8", "Shape 9", "Text 10",
                     "Shape 11", "Shape 12", "Text 13", "Shape 14", "Shape 15", "Text 16"):
            remove(s[name])
        inch = 914400
        body, note = s["Text 2"], s["Text 3"]
        top, bottom, width = 2.15, 6.6, 11.2
        if spec.get("note"):
            # A small grey line under the text, e.g. why an email works.
            lines = -(-len(spec["note"]) // 150)
            height = 0.25 * lines
            note.left, note.width = body.left, Emu(int(inch * width))
            note.top, note.height = Emu(int(inch * (bottom - height))), Emu(int(inch * height))
            set_text(note, spec["note"])
            run = note.text_frame.paragraphs[0].runs[0]
            run._r.find(qn("a:rPr")).set("sz", "1200")
            run.font.italic = True
            run.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)
            note.text_frame.paragraphs[0]._p.find(qn("a:pPr")).find(qn("a:lnSpc")).find(qn("a:spcPts")).set("val", "1600")
            bottom -= height + 0.2
        else:
            remove(note)
        body.top, body.width = Emu(int(inch * top)), Emu(int(inch * width))
        body.height = Emu(int(inch * (bottom - top)))
        fill_copy(body, spec["text"], width, bottom - top, spec.get("heading"))
    elif t == "cards":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        slots = [("Shape 2", "Text 3", "Text 4", "Text 5"), ("Shape 6", "Text 7", "Text 8", "Text 9"),
                 ("Shape 10", "Text 11", "Text 12", "Text 13")]
        cards = spec["cards"][:3]
        for i, (card, num, head, body) in enumerate(slots):
            if i < len(cards):
                set_text(s[num], i + 1)
                set_text(s[head], cards[i][0])
                set_text(s[body], cards[i][1])
            else:
                for name in (card, num, head, body):
                    remove(s[name])
        used = slots[:len(cards)]
        chars = 25
        if len(cards) < 3:
            # Fewer cards than the template's 3: share the full width between them (it spans 0.89in to 12.44in).
            inch = 914400
            width = (11.55 - 0.33 * (len(cards) - 1)) / len(cards)
            for i, (card, num, head, body) in enumerate(used):
                left = 0.89 + i * (width + 0.33)
                s[card].left, s[card].width = Emu(int(inch * left)), Emu(int(inch * width))
                s[num].left = Emu(int(inch * (left + 0.33)))
                for name in (head, body):
                    s[name].left, s[name].width = Emu(int(inch * (left + 0.33))), Emu(int(inch * (width - 0.58)))
            chars = int(25 * (width - 0.58) / 3.05)
        grow_cards(s, [(card, body) for card, _, _, body in used], [c[1] for c in cards], chars_per_line=chars)
    elif t == "steps":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        slots = [("Text 2", "Shape 3", "Text 4", "Text 5"), ("Text 6", "Shape 7", "Text 8", "Text 9"),
                 ("Text 10", "Shape 11", "Text 12", "Text 13"), ("Text 14", None, "Text 15", "Text 16")]
        steps = spec["steps"]
        for i, (num, line, head, body) in enumerate(slots):
            if i < len(steps):
                set_text(s[num], i + 1)
                set_text(s[head], steps[i][0])
                set_text(s[body], steps[i][1])
                if line and i == len(steps) - 1:
                    remove(s[line])
            else:
                for name in (num, line, head, body):
                    if name:
                        remove(s[name])
        # Spread fewer than 4 steps across the full width (the template spaces 4 columns 2.89in apart).
        if 1 < len(steps) < 4:
            inch = 914400
            pitch = 11.56 / len(steps)
            for i, (num, line, head, body) in enumerate(slots[:len(steps)]):
                left = 0.89 + i * pitch
                s[num].left = Emu(int(inch * left))
                for name in (head, body):
                    s[name].left = Emu(int(inch * left))
                    s[name].width = Emu(int(inch * (pitch - 0.26)))
                if line and i < len(steps) - 1:
                    s[line].left = Emu(int(inch * (left + 0.78)))
                    s[line].width = Emu(int(inch * (pitch - 1.11)))
    elif t == "before_after":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        for side, (lab, head, pts) in (("left", ("Text 3", "Text 4", "Text 5")), ("right", ("Text 7", "Text 8", "Text 9"))):
            set_text(s[lab], spec[side]["label"].upper())
            set_text(s[head], spec[side]["heading"])
            set_points(s[pts], spec[side]["points"])
    elif t == "table":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        fill_table(s["Table 0"], spec["columns"], spec["rows"], spec.get("widths"))
    elif t == "quote":
        set_text(s["Text 0"], spec.get("eyebrow", "WHAT THE CLIENT SAID"))
        set_text(s["Text 1"], f'“{spec["quote"]}”')
        set_text(s["Text 3"], spec.get("company", "").upper())
        set_text(s["Text 4"], spec.get("name", ""))
        set_text(s["Text 5"], spec.get("role", ""))
    elif t == "next_steps":
        spec = {**closing(deck.get("skill", "icp-generator")), **spec}
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], spec.get("line", ""))
        button = s["Text 3"]
        set_text(button, spec.get("button", "Book a call"))
        button.width = Emu(max(button.width, int(914400 * (0.115 * len(button.text_frame.text) + 0.6))))
        if spec.get("url"):
            # A link on the whole button keeps the button's own text style (a text link turns it blue).
            button.click_action.hyperlink.address = spec["url"]
        contacts = spec.get("contacts", [])
        x = s["Text 4"].left
        for i, (lab, val) in enumerate([("Text 4", "Text 5"), ("Text 6", "Text 7"), ("Text 8", "Text 9")]):
            if i < len(contacts):
                set_text(s[lab], contacts[i][0].upper())
                set_text(s[val], contacts[i][1])
                w = Emu(int(914400 * max(1.2, 0.12 * max(len(contacts[i][1]), len(contacts[i][0])) + 0.2)))
                for name in (lab, val):
                    s[name].left = x
                    s[name].width = w
                x += w + Emu(457200)
            else:
                remove(s[lab])
                remove(s[val])
    else:
        raise SystemExit(f"Unknown slide type: {t}")


def main(spec_path, template_path, out_path):
    deck = json.load(open(spec_path, encoding="utf-8"))
    prs = Presentation(template_path)
    templates = list(prs.slides)
    for page, spec in enumerate(deck["slides"], 1):
        slide = duplicate(prs, templates[TEMPLATE_INDEX[spec["type"]]])
        build(slide, spec, deck)
        footer(slide, deck["deck_title"], page)
    drop_slides(prs, len(templates))
    prs.save(out_path)
    print(f"saved {out_path} ({len(deck['slides'])} slides)")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    main(*sys.argv[1:])
