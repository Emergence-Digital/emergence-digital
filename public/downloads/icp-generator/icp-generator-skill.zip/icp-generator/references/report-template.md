# ICP Report Template

Use this structure. Replace everything in [brackets]. Keep it to 3 to 4 pages. Quote clients' real words where you have them. Mark inferences with *(inferred)*.

---

# Ideal Customer Profile: [Firm name]

*Built with the Centurion Strategy ICP Generator · [date]*

## The short version

[2 to 3 sentences anyone in the business could repeat. Example: "We do our best work for Australian manufacturers and logistics firms with 100 to 500 staff, one stretched IT manager and an ageing on-prem ERP. They call us when a new CFO or an audit forces the issue, and they choose us because we're specialists who explain things plainly."]

*Based on [the owner's / the team's] view of [N] best and [N] worst clients. Validate it with clients (see section 9).*

## 1. Who we serve (the account)

| | Ideal |
|---|---|
| Industries | [ ] |
| Size | [employees / seats / revenue] |
| Location | [ ] |
| Internal IT | [ ] |
| Ownership and stage | [ ] |
| Regulations | [ ] |
| Technology | [platforms, and the state they're in] |
| Current provider | [who looks after them before us] |

## 2. Tiers

**Tier 1, Ideal: go after these first**
[Pattern match + an active trigger. 2 to 3 bullets.]

**Tier 2, Good fit: nurture until a trigger appears**
[2 to 3 bullets.]

**Tier 3, Opportunistic: take it if it comes, don't spend to find it**
[1 to 2 bullets.]

**Anti-ICP: say no or refer on**
[The disqualifiers from Round 8 and the worst-client patterns from Round 1.]

## 3. When they buy: trigger watchlist

| Trigger | What to look for | Where to spot it |
|---|---|---|
| [e.g. New CIO or CFO] | [Leadership announcement] | [LinkedIn job changes, press] |
| [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] |

[3 to 6 rows, most common trigger first.]

## 4. Who's in the room: buying committee

For each of 2 to 3 personas:

### [Persona name, e.g. "The stretched IT manager"]
- **Role:** [title and seniority] · **Part in the deal:** [first contact / signer / evaluator / blocker]
- **What they care about:** [ ]
- **What worries them:** [ ]
- **Where they look for help:** [ ]
- **Proof they need:** [ ]
- **In their words:** "[quote, if available]"

## 5. Why they switch to us

| Force | What we heard |
|---|---|
| Push (frustration with what they had) | [ ] |
| Pull (what attracted them to us) | [ ] |
| Anxiety (what nearly stopped them) | [ ] |
| Habit (why they'd stayed put, and who they go with instead) | [ ] |

**Why us over the big players:** [their words]

## 6. Messaging angles

3 to 5 angles drawn from the triggers, anxieties and values above. For each one: the angle, the persona it's for, and a one-line hook in the client's language.

1. **[Angle]** for [persona]: "[hook]"
2. ...

## 7. Where to find them

[The top channels from Round 7, ranked, with one line each on how to use it. Include list-building filters for LinkedIn Sales Navigator or a data tool, e.g. industry, headcount, location, job titles.]

## 8. Account scoring

Score any account out of 100. 70+ = Tier 1, 50 to 69 = Tier 2, under 50 = Tier 3. Any disqualifier = Anti-ICP regardless of score.

| Criterion | Weight | Full marks (10) | Half marks (5) | Zero (0) |
|---|---|---|---|---|
| [e.g. Industry] | [20] | [Manufacturing, logistics] | [Wholesale, construction] | [Anything else] |
| [e.g. Headcount] | [15] | [100 to 500] | [50 to 99 or 501 to 1,000] | [Outside that] |
| [e.g. Internal IT] | [ ] | [ ] | [ ] | [ ] |
| [e.g. Active trigger] | [ ] | [ ] | [ ] | [ ] |
| ... | | | | |
| **Total** | **100** | | | |

Score = sum of (weight × marks ÷ 10).

## 9. Gaps to fill

[Anything left vague or skipped, and how to fix it. e.g. "You weren't sure why clients chose you. Ask your three best clients that one question this month."]

## 10. Companies that fit right now

*A starting list from public sources. Sizes are estimates; check before reaching out.*

| Company | City | Est. size | Why it fits | Trigger spotted | Score | Tier | Source |
|---|---|---|---|---|---|---|---|
| [ ] | [ ] | [e.g. "200 to 500 staff, est."] | [one line] | [trigger, or "none found"] | [e.g. "82 (70% checked)"] | [ ] | [link] |

*Sorted by tier, then % checked, then score.*

**Via a partner only:** [organisations that fit except they're too large to buy from you directly, one line each, or leave this out]

**To check on the first call:** [the criteria public sources couldn't answer, e.g. who runs IT, tech stack]

**Who to approach:** [role titles from section 4, not individual names]

## Next steps

1. Add your 3 best clients to the spreadsheet as new rows. They should come out "Go after now"; if not, adjust the weights.
2. Check the companies in section 10 and build on them using the filters in section 7.
3. Turn section 6 into an outbound sequence (Centurion: Attract → Outbound).

---

*This ICP is the first step of the Centurion Strategy (Attract, Engage, Convert) by Emergence Digital.*
