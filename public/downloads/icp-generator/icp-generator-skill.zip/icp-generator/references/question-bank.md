# ICP Question Bank (detailed version)

Quick mode (`quick-questions.md`) is the default. Use this bank for its fallbacks, for the optional deep dive after the report, or when someone asks for the detailed version from the start.

★ = core question in the detailed version. Unmarked = optional depth.
Give the lettered options as written. Always allow "other" and "not sure".

---

## Round 0: Your firm

*Why: what they sell, where and at what size decides who they can serve.*

★ **0.1 What type of IT business are you?** (pick up to two)
a) Managed service provider (MSP)
b) Cybersecurity firm or MSSP
c) SaaS or software product company
d) Cloud provider or cloud consultancy
e) ERP or CRM partner (SAP, Oracle, Dynamics, NetSuite, Salesforce, HubSpot…)
f) Software development or digital agency
g) IT consultancy or professional services

★ **0.2 What are your service lines, and which one is most profitable?**
*If pre-filled from the website, only ask which is most profitable.*

0.2b Which service line usually brings new clients in the door?

★ **0.3 How big is your team?**
a) solo  b) 2–10  c) 11–50  d) 51–200  e) 200+

★ **0.4 Where can you deliver?**
a) on-site in one city  b) one state  c) nationally (remote)  d) Australia and NZ  e) global

★ **0.5 What's a typical client worth to you?**
a) Project only: average value? b) Recurring: monthly or annual value? c) Both
Also: how long do clients usually stay?

0.6 How long is your sales cycle, from first conversation to signed?
a) under 2 weeks  b) 2–6 weeks  c) 2–3 months  d) 3–6 months  e) 6+ months

0.7 Where does new business come from today? (rank)
a) Referrals  b) Vendor or partner referrals (e.g. Microsoft, SAP)  c) Outbound  d) Inbound (website, content)  e) Events  f) Tenders or panels

---

## Round 1: Evidence, your best and worst clients

*Why: this is the anchor for everything else. Real patterns beat wishful thinking.*

★ **1.1 Name 3 to 5 clients you'd clone tomorrow.** (Names or descriptions like "the logistics company in Brisbane" are fine.)
Think about: most profitable, easiest to work with, renewed or expanded, referred others.

★ **1.2 For each one, what makes them great?** One line each is enough.

★ **1.3 Name 1 or 2 clients you'd never take on again, and why.**

1.4 Which clients bought more after the first engagement? What did they buy next?

1.5 Which client relationships did you lose, and why?

*If they have few clients (solo or early stage): ask about the clients they've enjoyed and profited from most, including from a previous role.*

---

## Round 2: Firmographics (the client's business)

*Why: these are the filters for lists, ads and outbound targeting.*

★ **2.1 Which industries are your best clients in?**
a) Manufacturing  b) Logistics, transport, shipping  c) Financial services, insurance  d) Health, aged care  e) Professional services (legal, accounting, engineering)  f) Retail, ecommerce  g) Construction, property  h) Mining, energy, utilities  i) Government, education  j) Not-for-profit  k) Tech companies  l) Automotive

★ **2.2 How big are they?**
Employees: a) under 20  b) 20–100  c) 100–500  d) 500–2,000  e) 2,000+
Also, if relevant: seats, endpoints or users; annual revenue band.

★ **2.3 Where are they?**
a) Same city as you  b) Same state  c) Anywhere in Australia  d) ANZ  e) Global

★ **2.4 What does their internal IT look like?**
a) Nobody; the office manager or owner handles it
b) One generalist IT person
c) An IT manager with a small team
d) A CIO or Head of IT with a full team
e) Large IT department with specialist teams
*This is one of the strongest fit signals for IT firms. Probe it.*

2.5 Who owns them?
a) Founder or family owned  b) Private equity backed  c) Publicly listed  d) Government  e) Not-for-profit  f) Subsidiary of a global group

2.6 What stage are they at?
a) Scaling fast  b) Steady  c) Restructuring or cost-cutting  d) Recently merged or acquired

2.7 What regulations or standards apply to them? *(Core for the Cyber branch.)*
a) Essential Eight  b) ISO 27001  c) APRA CPS 234  d) SOCI Act (critical infrastructure)  e) Privacy Act or health records  f) PCI DSS  g) Government (PSPF, IRAP)  h) None that matter

---

## Round 3: Technographics (the client's technology)

*Why: the stack tells you who can actually use what you sell, and when.*

★ **3.1 Which productivity suite do they use?**
a) Microsoft 365  b) Google Workspace  c) Mixed or legacy (e.g. on-prem Exchange)

★ **3.2 Where does their infrastructure live?**
a) Azure  b) AWS  c) GCP  d) mostly on-premises  e) hybrid

3.3 Which business systems matter? (free text: ERP, CRM, ITSM such as ServiceNow, Freshservice or Jira)
*Core for the ERP/CRM partner and SaaS branches.*

★ **3.4 What state is their technology in when they come to you?**
a) Legacy and on-premises
b) Partly migrated, mid-transformation
c) Recently modernised but poorly integrated
d) Modern and well run; they need specialist help

★ **3.5 Who looks after their IT before you?**
a) Internal team only  b) Another MSP or local provider  c) A big consultancy or global SI  d) Nobody  e) The vendor directly

3.6 Which tools in their stack signal a great fit? Which signal a bad fit?

3.7 How much technical debt or how many disconnected systems do they have?
a) Lots: spreadsheets and manual workarounds everywhere  b) Some  c) Very little

**Then add the branch questions for their business type (below).**

---

## Round 4: Problems and triggers

*Why: fit tells you who; triggers tell you when. This is where outbound timing and ad angles come from.*

★ **4.1 Think about your best clients. What was going on in their business just before they called you, and how urgent was it?**
*Don't give an example answer here. Examples get copied back.*

★ **4.2 Which of these triggers do you see most often?** (pick all that apply)
a) New CIO, CFO or CEO
b) Cyber incident or near miss
c) Failed audit, insurance renewal or compliance deadline
d) Merger, acquisition or restructure
e) Funding round or rapid growth (lots of hiring)
f) End of support for a key system (e.g. Windows 10, SAP ECC)
g) A failed project or implementation
h) Contract with the current provider ending
i) Moving offices or opening new sites
j) Board or leadership pushing for AI or digital transformation
k) Costs blowing out (cloud, licences)

★ **4.3 What had they tried before you, and why didn't it work?**

4.4 What was doing nothing costing them? (money, risk, time, reputation)

4.5 In their words, what outcome did they actually care about?

*High value for all branches. Don't skip in core-only mode.*

---

## Round 5: The buying committee (demographics)

*Why: you sell to people, not logos. Messaging changes by role.*

★ **5.1 Who usually reaches out first or takes the first meeting?**
a) Owner or CEO  b) CFO or finance  c) COO or operations  d) CIO, CTO or Head of IT  e) IT manager  f) Security lead  g) A department head (e.g. sales, HR)

★ **5.2 Who signs off?**
Same options as 5.1, or h) the board.

★ **5.3 Who can slow down or block the deal?**
a) Procurement  b) Security or risk  c) Finance  d) Internal IT who feel threatened  e) Legal  f) Nobody really

5.4 How many people are usually involved in the decision?
a) 1  b) 2–3  c) 4–6  d) 7+
Does it change with deal size?

5.5 How do they buy?
a) Direct conversation  b) Shortlist of 2–3 providers  c) Formal RFP or tender  d) Government panel

---

## Round 6: Psychographics (how they think)

*Why: attitudes and anxieties drive messaging and objection handling.*

★ **6.1 How do your best clients feel about technology?**
a) Early adopters: want the new thing
b) Pragmatic: will invest if the case is clear
c) Cautious: need lots of proof
d) Reluctant: tech is a necessary evil

★ **6.2 What do they value most in a provider?** (pick top 3)
a) Fast response  b) Certainty, no surprises  c) Specialist expertise  d) Strategic advice, not just tickets  e) Local presence  f) Price  g) Being treated as important (not a small fish)  h) Proven in their industry

★ **6.3 What worried them before they signed?**
a) Getting locked in  b) The project failing  c) Disruption to the business  d) Looking bad to the board  e) Cost blowouts  f) Losing control  g) You being too small

★ **6.4 Why did they choose you over a big consultancy, a global SI or a competitor?** Use their actual words if you can remember them.

★ **6.5 If they switched from another provider, what frustrated them most?**
a) Slow response  b) Reactive, never proactive  c) No strategic guidance  d) Billing surprises  e) Lack of AI or automation capability  f) Constant staff turnover  g) Recurring problems never fixed

---

## Round 7: Behaviour (how they buy and engage)

*Why: tells you which channels and content will reach them.*

★ **7.1 Where do they go when they need help?** (pick top 3)
a) Peers or referrals  b) LinkedIn  c) Google  d) Vendor or partner referral  e) Industry events or associations  f) Analysts or advisors  g) Their accountant or board

★ **7.2 What proof do they need before buying?**
a) Case studies  b) References they can call  c) Certifications or partner status  d) A paid pilot or audit  e) Meeting the delivery team  f) Price comparisons

7.3 What do they actually read, watch or attend?

7.4 How do they respond to outreach?
a) Reply to cold email  b) Accept LinkedIn messages  c) Only via referral  d) Not sure

7.5 Once they're a client, how do they usually grow with you?

---

## Round 8: Disqualifiers

*Why: an ICP isn't done until it says who to turn away.*

★ **8.1 What red flags tell you to walk away?**
a) Budget below a set amount (what amount?)
b) Wants cheapest price only
c) No executive sponsor
d) Just wants extra hands, not outcomes
e) Unrealistic timelines
f) Particular industries
g) Previously churned through several providers
h) Other

---

# Branch questions (insert into Round 3)

## MSP
- ★ Fully managed or co-managed with their internal IT?
- ★ Typical number of users or endpoints?
- When does their current MSP contract usually end?
- What do they complain about most with their previous MSP?

## Cybersecurity / MSSP
- ★ What's their security maturity? a) basic tools only  b) policies but gaps  c) dedicated security person  d) mature program with a SOC
- ★ Have they had an incident, failed an audit or had cyber insurance questions?
- Which framework are they working toward? (Essential Eight maturity level, ISO 27001, SOC 2, CPS 234)
- Who owns security internally?

## SaaS / software product
- ★ How many users per customer, and which team uses it day to day?
- ★ Who owns the budget for your product? (IT, a department, the owner)
- What must it integrate with to be bought?
- What did they use before? (spreadsheets, a competitor, an in-house build)

## Cloud
- ★ Where are they in the move? a) still on-prem  b) planning  c) mid-migration  d) in the cloud, optimising
- ★ Roughly what's their monthly cloud spend, and are costs a problem?
- Which workloads matter most? (data, apps, infrastructure, AI)

## ERP / CRM partner
- ★ Which platform and version? (e.g. SAP ECC vs S/4HANA, Dynamics GP vs Business Central)
- ★ Where are they? a) selecting  b) implementing  c) live, need support  d) live and unhappy
- Do they have a support arrangement after go-live?
- Who was their previous partner, and why did they leave?

## Software development / digital agency
- ★ What do they need built? a) customer-facing apps  b) internal tools  c) integrations  d) AI or automation
- ★ Do they have in-house developers?
- Fixed-price projects or ongoing team?

## IT consultancy
- ★ What decisions do they bring you in for? (strategy, vendor selection, transformation, project rescue)
- ★ How many internal stakeholders do you usually advise?
- Do you implement as well, or advise only?
