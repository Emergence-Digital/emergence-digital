#!/usr/bin/env python3
"""Turn an ICP report into a deck built on the Emergence Digital master template.

Usage:
    python3 scripts/make_deck.py deck.json assets/ICP-Deck-Template.pptx icp-report.pptx

deck.json:
{
  "client": "DPC Services Group",
  "date": "November 2026",
  "deck_title": "Ideal Customer Profile",
  "slides": [ {"type": "...", ...}, ... ]
}

Slide types (each copies one design from the template):
  cover        title, intro (the client's name and the month are filled in; eyebrow and payoff override them)
  agenda       title, items: [[heading, line], ...]  (up to 6)
  section      eyebrow, title, line
  text         eyebrow, title, paragraphs: [one, two], label, points: [...]  (up to 4 points)
  statement    eyebrow, title, payoff, line
  cards        eyebrow, title, cards: [[heading, text], ...]  (exactly 3)
  steps        eyebrow, title, steps: [[heading, text], ...]  (up to 4)
  before_after eyebrow, title, left: {label, heading, points}, right: {label, heading, points}
  table        eyebrow, title, columns: [...], rows: [[...], ...], widths: [...] (optional)
  quote        eyebrow, quote, company, name, role
  next_steps   Emergence Digital's closing slide. Leave every field out to use CLOSING below;
               title, line, button, url and contacts: [[LABEL, value], ...] (up to 3) override it.

Needs python-pptx (pip install python-pptx).
"""
import copy
import json
import sys

from pptx import Presentation
from pptx.oxml.ns import qn
from pptx.util import Emu

CLOSING = {
    "title": "Let’s talk.",
    "line": "We’ll show you how to turn this ICP into qualified conversations every month.",
    "button": "Book a Pipeline Scale Plan call",
    "url": "https://emergencedigital.com.au/pipeline-scale-plan-call"
           "?utm_source=lead-magnet&utm_medium=claude-skill&utm_campaign=icp-generator",
    "contacts": [["Email", "contact@emergencedigital.com.au"]],
}

TEMPLATE_INDEX = {"cover": 0, "agenda": 1, "section": 2, "text": 3, "cards": 4, "numbers": 5, "statement": 6,
                  "quote": 7, "before_after": 8, "steps": 9, "table": 10, "image": 11, "next_steps": 12}


# ---------- slide copying ----------
def duplicate(prs, src):
    new = prs.slides.add_slide(src.slide_layout)
    for ph in list(new.placeholders):
        ph._element.getparent().remove(ph._element)
    src_bg = src._element.cSld.find(qn("p:bg"))
    if src_bg is not None:
        new._element.cSld.insert(0, copy.deepcopy(src_bg))
    tree = new.shapes._spTree
    for el in src.shapes._spTree.iterchildren():
        if el.tag in (qn("p:sp"), qn("p:graphicFrame"), qn("p:grpSp"), qn("p:cxnSp"), qn("p:pic")):
            tree.append(copy.deepcopy(el))
    return new


def drop_slides(prs, count):
    """Remove the first `count` slides (the template's own examples)."""
    sld_ids = prs.slides._sldIdLst
    for sld_id in list(sld_ids)[:count]:
        prs.part.drop_rel(sld_id.get(qn("r:id")))
        sld_ids.remove(sld_id)


# ---------- text helpers ----------
def shapes_by_name(slide):
    return {sh.name: sh for sh in slide.shapes}


def remove(shape):
    shape._element.getparent().remove(shape._element)


def set_text(shape, text):
    """Replace a shape's text, keeping the look of its first run."""
    tf = shape.text_frame
    paras = tf.paragraphs
    for p in paras[1:]:
        p._p.getparent().remove(p._p)
    p = paras[0]
    runs = p.runs
    if not runs:
        p.add_run()
        runs = p.runs
    for r in runs[1:]:
        r._r.getparent().remove(r._r)
    runs[0].text = str(text)


def set_points(shape, points):
    """Fill a bulleted text box with one paragraph per point, copying the first paragraph's style."""
    tf = shape.text_frame
    first = copy.deepcopy(tf.paragraphs[0]._p)
    body = tf._txBody
    for p in list(tf.paragraphs):
        body.remove(p._p)
    for i, point in enumerate(points):
        p = copy.deepcopy(first)
        if i == 0:
            spc = p.find(qn("a:pPr") + "/" + qn("a:spcBef"))
            if spc is not None:
                spc.getparent().remove(spc)
        runs = p.findall(qn("a:r"))
        for r in runs[1:]:
            p.remove(r)
        runs[0].find(qn("a:t")).text = str(point)
        body.append(p)


def footer(slide, deck_title, page):
    for sh in slide.shapes:
        if not sh.has_text_frame:
            continue
        t = sh.text_frame.text.strip()
        if t.startswith("Emergence Digital · "):
            set_text(sh, f"Emergence Digital · {deck_title}")
            sh.width = Emu(5486400)  # 6 in, so the footer stays on one line
        elif t.isdigit() and sh.top > 6000000:
            set_text(sh, page)


def fit_width(shape, text, inch_per_char, centre=False):
    """Widen a highlighted box so its text fits on one line (the template's highlight boxes are a fixed size)."""
    need = int(914400 * (inch_per_char * len(str(text)) + 0.4))
    if need > shape.width:
        mid = shape.left + shape.width // 2
        shape.width = Emu(need)
        if centre:
            shape.left = Emu(mid - need // 2)


def grow_cards(s, pairs, texts, chars_per_line=25, line_in=0.29):
    """Make all cards on a slide tall enough for the longest text (the card shapes don't grow by themselves)."""
    lines = max(-(-len(t) // chars_per_line) for t in texts)
    for card, body in pairs:
        bottom = s[body].top + int(914400 * (lines * line_in + 0.35))
        s[card].height = Emu(max(s[card].height, bottom - s[card].top))


# ---------- table ----------
def fill_table(shape, columns, rows, widths=None):
    tbl = shape.table._tbl
    grid = tbl.find(qn("a:tblGrid"))
    trs = tbl.findall(qn("a:tr"))
    head_tr, body_trs = trs[0], trs[1:]
    total = sum(int(gc.get("w")) for gc in grid.findall(qn("a:gridCol")))
    ncol = len(columns)

    def fit_cells(tr):
        tcs = tr.findall(qn("a:tc"))
        while len(tcs) > ncol:
            tr.remove(tcs[-1])
            tcs = tr.findall(qn("a:tc"))
        while len(tcs) < ncol:
            tr.append(copy.deepcopy(tcs[-1]))
            tcs = tr.findall(qn("a:tc"))
        return tcs

    gcs = grid.findall(qn("a:gridCol"))
    for gc in gcs:
        grid.remove(gc)
    weights = widths or [1] * ncol
    for w in weights:
        gc = copy.deepcopy(gcs[0])
        gc.set("w", str(int(total * w / sum(weights))))
        grid.append(gc)

    # Smaller type for bigger tables, so it stays on the slide.
    n = len(rows)
    size = (1600 if n <= 4 and ncol <= 4 else 1300 if (n <= 6 and ncol <= 6) or (n <= 8 and ncol <= 3)
            else 1100 if n <= 9 else 1000)
    height = {1600: 510480, 1300: 400000, 1100: 340000, 1000: 310000}[size]

    def write(tc, value, sz):
        p = tc.find(qn("a:txBody")).find(qn("a:p"))
        runs = p.findall(qn("a:r"))
        for r in runs[1:]:
            p.remove(r)
        r = runs[0]
        r.find(qn("a:t")).text = str(value)
        r.find(qn("a:rPr")).set("sz", str(sz))
        lnspc = p.find(qn("a:pPr") + "/" + qn("a:lnSpc"))
        if lnspc is not None:
            lnspc.getparent().remove(lnspc)
        tcpr = tc.find(qn("a:tcPr"))
        tcpr.set("marT", "60000")
        tcpr.set("marB", "60000")
        tcpr.set("marL", "110000")
        tcpr.set("marR", "110000")

    for tc, v in zip(fit_cells(head_tr), columns):
        write(tc, v, size)
    head_tr.set("h", str(height))

    for tr in body_trs:
        tbl.remove(tr)
    for i, row in enumerate(rows):
        tr = copy.deepcopy(body_trs[i % len(body_trs)])
        tr.set("h", str(height))
        for tc, v in zip(fit_cells(tr), list(row) + [""] * (ncol - len(row))):
            write(tc, v, size)
        tbl.append(tr)
    shape.height = height * (n + 1)


# ---------- each slide type ----------
def build(slide, spec, deck):
    s = shapes_by_name(slide)
    t = spec["type"]
    if t == "cover":
        payoff = spec.get("payoff") or deck["client"]
        set_text(s["Text 0"], spec.get("eyebrow") or deck["date"].upper())
        set_text(s["Text 1"], spec.get("title", "Ideal Customer Profile"))
        set_text(s["Text 2"], payoff)
        fit_width(s["Text 2"], payoff, 0.27)
        set_text(s["Text 3"], spec.get("intro", ""))
    elif t == "text":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        paras = spec.get("paragraphs", [])
        one, two = s["Text 2"], s["Text 3"]
        set_text(one, paras[0] if paras else "")
        # The template's boxes hold two lines each: make room for longer paragraphs (16pt, about 52 characters a line).
        lines = max(2, -(-len(paras[0]) // 52)) if paras else 2
        one.height = Emu(int(914400 * 0.33 * lines))
        if len(paras) > 1:
            set_text(two, paras[1])
            two.top = Emu(one.top + one.height + int(914400 * 0.2))
            two.height = Emu(int(914400 * 0.33 * max(2, -(-len(paras[1]) // 52))))
        else:
            remove(two)
        set_text(s["Text 4"], spec.get("label", "KEY POINTS").upper())
        points = spec.get("points", [])
        for i, (box, dot, txt) in enumerate([("Shape 5", "Shape 6", "Text 7"), ("Shape 8", "Shape 9", "Text 10"),
                                              ("Shape 11", "Shape 12", "Text 13"), ("Shape 14", "Shape 15", "Text 16")]):
            if i < len(points):
                set_text(s[txt], points[i])
                s[txt].width = Emu(s[box].left + s[box].width - s[txt].left - int(914400 * 0.15))
            else:
                for name in (box, dot, txt):
                    remove(s[name])
    elif t == "agenda":
        set_text(s["Text 1"], spec.get("title", "What we'll cover"))
        slots = [("Shape 2", "Text 3", "Text 4", "Text 5"), ("Shape 10", "Text 11", "Text 12", "Text 13"),
                 ("Shape 18", "Text 19", "Text 20", "Text 21"), ("Shape 6", "Text 7", "Text 8", "Text 9"),
                 ("Shape 14", "Text 15", "Text 16", "Text 17"), ("Shape 22", "Text 23", "Text 24", "Text 25")]
        items = spec["items"]
        for i, (line, num, head, sub) in enumerate(slots):
            if i < len(items):
                set_text(s[num], f"{i + 1:02d}")
                set_text(s[head], items[i][0])
                set_text(s[sub], items[i][1])
            else:
                for name in (line, num, head, sub):
                    remove(s[name])
    elif t == "section":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], spec.get("line", ""))
    elif t == "statement":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], spec.get("payoff", ""))
        fit_width(s["Text 2"], spec.get("payoff", ""), 0.42, centre=True)
        if spec.get("line"):
            set_text(s["Text 3"], spec["line"])
        else:
            remove(s["Text 3"])
    elif t == "cards":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        for (num, head, body), (h, b), i in zip([("Text 3", "Text 4", "Text 5"), ("Text 7", "Text 8", "Text 9"),
                                                 ("Text 11", "Text 12", "Text 13")], spec["cards"], range(3)):
            set_text(s[num], i + 1)
            set_text(s[head], h)
            set_text(s[body], b)
        grow_cards(s, [("Shape 2", "Text 5"), ("Shape 6", "Text 9"), ("Shape 10", "Text 13")], [c[1] for c in spec["cards"]])
    elif t == "steps":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        slots = [("Text 2", "Shape 3", "Text 4", "Text 5"), ("Text 6", "Shape 7", "Text 8", "Text 9"),
                 ("Text 10", "Shape 11", "Text 12", "Text 13"), ("Text 14", None, "Text 15", "Text 16")]
        steps = spec["steps"]
        for i, (num, line, head, body) in enumerate(slots):
            if i < len(steps):
                set_text(s[num], i + 1)
                set_text(s[head], steps[i][0])
                set_text(s[body], steps[i][1])
                if line and i == len(steps) - 1:
                    remove(s[line])
            else:
                for name in (num, line, head, body):
                    if name:
                        remove(s[name])
        # Spread fewer than 4 steps across the full width (the template spaces 4 columns 2.89in apart).
        if 1 < len(steps) < 4:
            inch = 914400
            pitch = 11.56 / len(steps)
            for i, (num, line, head, body) in enumerate(slots[:len(steps)]):
                left = 0.89 + i * pitch
                s[num].left = Emu(int(inch * left))
                for name in (head, body):
                    s[name].left = Emu(int(inch * left))
                    s[name].width = Emu(int(inch * (pitch - 0.26)))
                if line and i < len(steps) - 1:
                    s[line].left = Emu(int(inch * (left + 0.78)))
                    s[line].width = Emu(int(inch * (pitch - 1.11)))
    elif t == "before_after":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        for side, (lab, head, pts) in (("left", ("Text 3", "Text 4", "Text 5")), ("right", ("Text 7", "Text 8", "Text 9"))):
            set_text(s[lab], spec[side]["label"].upper())
            set_text(s[head], spec[side]["heading"])
            set_points(s[pts], spec[side]["points"])
    elif t == "table":
        set_text(s["Text 0"], spec["eyebrow"])
        set_text(s["Text 1"], spec["title"])
        fill_table(s["Table 0"], spec["columns"], spec["rows"], spec.get("widths"))
    elif t == "quote":
        set_text(s["Text 0"], spec.get("eyebrow", "WHAT THE CLIENT SAID"))
        set_text(s["Text 1"], f'“{spec["quote"]}”')
        set_text(s["Text 3"], spec.get("company", "").upper())
        set_text(s["Text 4"], spec.get("name", ""))
        set_text(s["Text 5"], spec.get("role", ""))
    elif t == "next_steps":
        spec = {**CLOSING, **spec}
        set_text(s["Text 1"], spec["title"])
        set_text(s["Text 2"], spec.get("line", ""))
        button = s["Text 3"]
        set_text(button, spec.get("button", "Book a call"))
        button.width = Emu(max(button.width, int(914400 * (0.115 * len(button.text_frame.text) + 0.6))))
        if spec.get("url"):
            # A link on the whole button keeps the button's own text style (a text link turns it blue).
            button.click_action.hyperlink.address = spec["url"]
        contacts = spec.get("contacts", [])
        x = s["Text 4"].left
        for i, (lab, val) in enumerate([("Text 4", "Text 5"), ("Text 6", "Text 7"), ("Text 8", "Text 9")]):
            if i < len(contacts):
                set_text(s[lab], contacts[i][0].upper())
                set_text(s[val], contacts[i][1])
                w = Emu(int(914400 * max(1.2, 0.12 * max(len(contacts[i][1]), len(contacts[i][0])) + 0.2)))
                for name in (lab, val):
                    s[name].left = x
                    s[name].width = w
                x += w + Emu(457200)
            else:
                remove(s[lab])
                remove(s[val])
    else:
        raise SystemExit(f"Unknown slide type: {t}")


def main(spec_path, template_path, out_path):
    deck = json.load(open(spec_path, encoding="utf-8"))
    prs = Presentation(template_path)
    templates = list(prs.slides)
    for page, spec in enumerate(deck["slides"], 1):
        slide = duplicate(prs, templates[TEMPLATE_INDEX[spec["type"]]])
        build(slide, spec, deck)
        footer(slide, deck.get("deck_title", "Ideal Customer Profile"), page)
    drop_slides(prs, len(templates))
    prs.save(out_path)
    print(f"saved {out_path} ({len(deck['slides'])} slides)")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    main(*sys.argv[1:])
